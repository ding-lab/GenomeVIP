<?php

$selectname = substr($_REQUEST["SELECTNAME"], 0, -2);
print_r($_REQUEST[$selectname]);

?>